<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Infopage extends Model
{
    //
}
