<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutslider extends Model
{
    protected $fillable = [
        'image', 'text',
    ];
}
