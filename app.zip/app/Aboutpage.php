<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutpage extends Model
{
    //
}
