<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gde extends Model
{
    //
}
