<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Example Component</div>

                    <div class="card-body">
<!--                        <image-uploader></image-uploader>-->
<!--                        <test-page></test-page>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
// import  ImageUploader from './ImageUploader';
import  HomePage from './HomePage';
// import  AboutPage from './ActivityPage';

    export default {
        mounted() {
            console.log('Component mounted.')
        },
        // components : {
        //     ImageUploader,
        //     HomePage
        // }
    }
</script>
